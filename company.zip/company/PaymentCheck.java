public  interface PaymentCheck{
	public double getGrossWage(); // returning the gross salary

	public String getDiscounts();

	public double calculateNetWage();

}